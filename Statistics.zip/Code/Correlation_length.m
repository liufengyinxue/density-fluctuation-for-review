function [CL] = Correlation_length(Data,k,Method)
% % %
% Copyright: Zhenpeng Ge, East China Normal University.
% Licence: MIT Licence
% 
% This function computes circularly averaged structure factor for 2D data in
% matrix form.
% Input:     
% Data:    a 2D matrix, like an image
% k:       a vector, wave number. Usually, k =0:1:floor(min(size(Data))/2) - 1,
%          and don't forget that the k needs to multiply by 2*pi/min(size(Data)) 
%          to become the coordinates of the Fourier space 
% Method:  a number, analyze data with binarization or a continuous field, 
%          "0" means binarization, "1" means continuous field
% Output:  
% SK:      a vector, circularly averaged structure factor.
% % % 

Img = double(Data) ;
[M1,M2] = size(Img) ;
if Method == 0 % for a binarization image
	img = double(Img > mean(Img(:))) ;
	img(img > 0) = 1 ;
	img(img == 0) = -1 ;
elseif Method == 1 % for a continuous field
	img = Img - mean(Img(:)) ; 
end
S = abs(fftshift(fft2(img))).^2/(M1*M2) ;
[m,n] = meshgrid(-M2/2:M2/2-1,-M1/2:M1/2-1) ;
phi = (0.05:0.05:1000)'/1000*2*pi ;
SK = zeros(length(k),1) ;
for ii=1:length(k)
    SK(ii,1) = mean(interp2(m,n,S,k(ii)*cos(phi),k(ii)*sin(phi))) ;
end
Kmax = dot(k,SK)/sum(SK) ;
CL = 2*pi/Kmax ;