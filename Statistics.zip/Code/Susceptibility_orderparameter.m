function [SusOP] = Susceptibility_orderparameter(data,Num)
% Input��data��a vector, save the spatial average magnetism of every sample
% Input:  Num, a number, save the lattice number
% Output: OP, a number, saves the spatial average of data
SusOP = Num*(dot(data,data)/length(data) - (mean(data))^2) ;