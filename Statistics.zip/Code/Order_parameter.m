function [OP] = Order_parameter(data)
% Input��data��a vector, save the spatial average magnetism of every sample
% Output: OP, a number, saves the spatial average of data
OP = mean(data) ;
end