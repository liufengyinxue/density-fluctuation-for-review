function [Svar] = Spatial_variance(data)
% Input: data, a matrix, saves the simulation field
Svar = var(data,0,'all') ;
end