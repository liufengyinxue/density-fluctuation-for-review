function [SSt] = Spatial_susceptibility(Data,Nbox,St)
[M1,~] = size(Data) ;
Scale = floor(M1/2) ;
padsize = Scale - 1 ;
ExpandedData = padarray(Data,[padsize padsize],'circular') ;
[M2,N2] = size(ExpandedData) ;
v = zeros(Nbox,1) ;
for j = 1:Nbox
    Index1 = randi([1,M2 - Scale + 1]) ; %the row index of top-left corner
    Index2 = randi([1,N2 - Scale + 1]) ; %the column index of top-left corner
    Indexrow = Index1:1:(Index1+Scale-1) ;
    Indexcol = Index2:1:(Index2+Scale-1) ;
    tempdata = ExpandedData(Indexrow,Indexcol) ;
    v(j,1) = mean(tempdata,'all') ;
end
SSt = (sum(v.^2,'all')/Nbox - St^2)*Scale^2 ;